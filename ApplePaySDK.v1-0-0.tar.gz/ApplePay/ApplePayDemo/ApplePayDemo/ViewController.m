//
//  ViewController.m
//  projnorth
//
//  Created by Moneris Solutions on 2015-04-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//


#import "ViewController.h"

@import PassKit;

#import <MpgClasses/MpgClasses.h>
#import <MpgClasses/ApplePayTokenPurchase.h>
#import <MpgClasses/ApplePayTokenPreauth.h>

@interface ViewController ()

@end

@implementation ViewController
@synthesize recurUnit;
@synthesize hasRecur;
@synthesize recurAmount;
@synthesize recurStartDate;
@synthesize recurStartNow;
@synthesize txtAmount;
@synthesize btnTransType;
@synthesize configured;
@synthesize transAmount;

NSArray * transTypes;

- (void)viewDidLoad
{
    [super viewDidLoad];

    if (!self.configured)
    {
        self.selectedIdx = -1;
        self.configured = YES;
        [self.txtAmount addTarget:self action:@selector(txtAmountDidChange:) forControlEvents:UIControlEventValueChanged];
    }
    
    transTypes = [NSArray arrayWithObjects: @"Purchase", @"Preauth", nil];
    [self loadPayButton];
    self.txtReceipt.editable = NO;
    
    [self updateGui];
    
    self.paymentNetworks = [[NSArray alloc] initWithObjects:PKPaymentNetworkAmex, PKPaymentNetworkVisa, PKPaymentNetworkMasterCard, nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillDisappear:(BOOL)animated
{
    self.transAmount = self.txtAmount.text;
}

-(void)txtAmountDidChange:(id)sender
{
    self.transAmount = self.txtAmount.text;
}
- (void)updateGui
{
    [self.txtAmount setText:self.transAmount];
    
    if (self.selectedIdx < [transTypes count] && self.selectedIdx >= 0)
    {
        [self.btnTransType setTitle:[transTypes objectAtIndex:self.selectedIdx] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnTransType setTitle:@"Select Transaction Type" forState:UIControlStateNormal];
    }

    [self updateRecurButton];
}

-(void)updateRecurButton
{
    if (self.hasRecur)
    {
        [self.btnRecur setTitle:@"Recur Enabled" forState:UIControlStateNormal];
        [self.btnRecur setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnRecur setTitle:@"Recur Disabled" forState:UIControlStateNormal];
        [self.btnRecur setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
}
- (void)loadPayButton
{
    CGFloat btnX = 15.0;
    CGFloat btnY = [UIScreen mainScreen].bounds.size.height - 60.0;
    CGFloat btnWidth = [UIScreen mainScreen].bounds.size.width - 30.0;
    CGFloat btnHeight = 50.0;
    
    self.btnPay = [PKPaymentButton buttonWithType:PKPaymentButtonTypeBuy style:PKPaymentButtonStyleWhite];
    self.btnPay.frame = CGRectMake(btnX, btnY, btnWidth, btnHeight);
    [self.btnPay addTarget:self action:@selector(applepayButtonDidPress:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.btnPay];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) applepayButtonDidPress:(id)sender
{
    
    if ([PKPaymentAuthorizationViewController canMakePayments])
    {
        NSLog(@"Can pay using networks");
        NSArray* paymentNetworks = @[PKPaymentNetworkAmex,PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
        
        if ([PKPaymentAuthorizationViewController canMakePaymentsUsingNetworks:paymentNetworks])
        {
            NSLog(@"Can make payment... let's start...");
            self.request = [[PKPaymentRequest alloc] init];
            
            self.request.currencyCode = @"CAD";
            self.request.countryCode = @"CA";

            self.request.merchantIdentifier = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"APPLEPAY_MERCHANT_ID"];
            
            self.request.requiredShippingAddressFields = PKAddressFieldAll;
            self.request.requiredBillingAddressFields = PKAddressFieldAll;
            
            self.request.merchantCapabilities = PKMerchantCapability3DS;
            self.request.supportedNetworks = paymentNetworks;
            
            self.request.paymentSummaryItems = @[
                                                 [PKPaymentSummaryItem summaryItemWithLabel:@"Item" amount:[NSDecimalNumber decimalNumberWithString:self.txtAmount.text]]
                                                 ];
            PKPaymentAuthorizationViewController *payView = [[PKPaymentAuthorizationViewController alloc] initWithPaymentRequest:self.request];
            if (payView)
            {
                payView.delegate = self;
                
                [self presentViewController:payView animated:YES completion:nil];
            }
            else
            {
                
            }
        }
        else
        {
            NSLog(@"Payment network is not available");
        }
    }
    else
    {
        NSLog(@"Payment is not allowed on this device");
    }
}

-(void)recurButtonDidPress:(id)sender
{
    self.transAmount = self.txtAmount.text;
    [self performSegueWithIdentifier:@"recurModal" sender:self];    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"recurModal"])
    {
        if (self.recurInfoView == nil)
        {
            self.recurInfoView = [segue destinationViewController];
            
            [((UIRecurViewController *)self.recurInfoView) setRecurEnabled:self.hasRecur startNow:[self.recurStartNow isEqualToString:@"true"] transAmount:self.transAmount recurAmount:self.recurAmount startDate:self.recurStartDate numOfRecur:self.numOfRecurs unit:self.recurUnit interval:self.recurInterval];
        }
        
    }
}

-(void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didAuthorizePayment:(PKPayment *)payment completion:(void (^)(PKPaymentAuthorizationStatus))completion
{
    NSLog(@"payment authroized!!!");

    MpgTransaction *transaction;
    Recur *recurInfo;
    if (self.hasRecur)
    {
        NSLog(@"This transaction has recur!!!");
        
        recurInfo = [Recur recurWithUnit:self.recurUnit StartNow:self.recurStartNow StartDate:self.recurStartDate NumberOfRecurs:[NSString stringWithFormat:@"%ld",self.numOfRecurs] Period:[NSString stringWithFormat:@"%ld", self.recurInterval] RecurAmount:self.recurAmount];
    }
    
    switch (self.selectedIdx) {
        case 0:
            transaction = (MpgTransaction *)[ApplePayTokenPurchase applePayTokenPurchaseWithOrderId: [NSString stringWithFormat:@"Spence-PROJ_NORTH-%ld", (long)[[NSDate date] timeIntervalSince1970]]
                                                                                    Payment:payment];
            [((ApplePayTokenPurchase *)transaction) setCustInfoWithPayment:payment Instructions:@"" ShippingCost:@"" Tax1:@"" Tax2:@"" Tax3:nil];
            [((ApplePayTokenPurchase *)transaction) setCvdInfo:[CvdInfo cvdInfoWithIndicator:@"1" Value:@"189"]];
            if (recurInfo != nil)
            {
                [((ApplePayTokenPurchase *)transaction) setRecur:recurInfo];
            }
            break;
        case 1:
            transaction = (MpgTransaction *)[ApplePayTokenPreauth applePayTokenPreauthWithOrderId: [NSString stringWithFormat:@"Spence-PROJ_NORTH-%ld", (long)[[NSDate date] timeIntervalSince1970]]
                                                                                          Payment:payment];
            [((ApplePayTokenPreauth *)transaction) setCustInfoWithPayment:payment Instructions:@"" ShippingCost:@"" Tax1:@"" Tax2:@"" Tax3:nil];
            [((ApplePayTokenPreauth *)transaction) setCvdInfo:[CvdInfo cvdInfoWithIndicator:@"1" Value:@"189"]];

            if (recurInfo != nil)
            {
                [((ApplePayTokenPreauth *)transaction) setRecur:recurInfo];
            }
            break;
        default:
            completion(PKPaymentAuthorizationStatusFailure);
            break;
    }

    //MpgRequest *req = [MpgRequest mpgRequestWithStoreId:@"moneris" ApiToken:@"EB6I4LlAHrSy2Y50oSXH" Transaction:transaction];
    //MpgRequest *req = [MpgRequest mpgRequestWithStoreId:@"monca82283" ApiToken:@"uoPVxgKq3op3zDJR8LyYz" Transaction:transaction];
    NSString * storeId = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"MONERIS_STORE_ID"];
    NSString * apiToken = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"MONERIS_API_TOKEN"];
    
    MpgRequest *req = [MpgRequest mpgRequestWithStoreId:storeId ApiToken:apiToken Transaction:transaction];
    [req setTestMode:YES];
    [req setProcCountry:@"CA"];
    
    HttpsPostRequest *post = [[HttpsPostRequest alloc] initWithHost:@"www3.moneris.com" Request:req];
    
    MpgResponse *resp = post.response;

    self.txtReceipt.text = [NSString stringWithFormat:@"Receipt ID:\t%@\nMessage:\t%@\nCAVV:\t%@\nResponse code:\t%@\nDevice Manufacturer Identifer:\t%@\n", resp.getReceiptId, resp.getMessage, resp.getCavv, resp.getResponseCode, resp.getDeviceManufacturerIdentifier];
    NSLog(@"%@", resp.getReceiptId);
    
    NSScanner *respCodeScanner = [NSScanner scannerWithString:resp.getResponseCode];
    
    if (([resp.getResponseCode integerValue] <=50) && ([respCodeScanner scanInt:NULL] && [respCodeScanner isAtEnd]))
    {
        completion(PKPaymentAuthorizationStatusSuccess);
    }
    else
    {
        completion(PKPaymentAuthorizationStatusFailure);
    }
    
    
}

-(void)transTypeButtonDidPress:(id)sender
{
    [self.txtAmount resignFirstResponder];
    UIActionSheet *transTypeSheet = [[UIActionSheet alloc] initWithTitle:@"Select Transactions Type"
                                                                delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Purchase", @"Preauth", nil];
    [transTypeSheet showInView:self.view];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    self.selectedIdx = buttonIndex;
    
    if (buttonIndex < [transTypes count])
    {
        [self.btnTransType setTitle:[transTypes objectAtIndex:buttonIndex] forState:UIControlStateNormal];
        if ([[transTypes objectAtIndex:buttonIndex] isEqualToString:@"Purchase"])
        {
            [self.btnRecur setEnabled:YES];
        }
        else
        {
            [self.btnRecur setEnabled:NO];
        }
    }
}

-(void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller
{
    NSLog(@"payment finished!!!");
    [controller dismissViewControllerAnimated:YES completion:nil];
}

-(void)recurEnabled:(BOOL)enabled startNow:(BOOL)startNow numRecur:(NSInteger)numRecur amount:(NSString *)amount startDate:(NSString *)date unit:(NSString *)unit interval:(NSInteger)interval
{
    self.hasRecur = enabled;
    self.configured = YES;
    
    if (self.hasRecur)
    {
        self.recurAmount = amount;
        self.recurStartDate = date;
        self.recurStartNow = (startNow)? @"true" : @"false";
        self.recurUnit = unit;
        self.numOfRecurs = numRecur;
        self.recurInterval = interval;
    }
    [self updateGui];
}
@end
