//
//  main.m
//  projnorth
//
//  Created by Moneris Solutions on 2015-04-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
