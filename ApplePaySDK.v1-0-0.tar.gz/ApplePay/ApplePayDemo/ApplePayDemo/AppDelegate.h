//
//  AppDelegate.h
//  projnorth
//
//  Created by Moneris Solutions on 2015-04-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

