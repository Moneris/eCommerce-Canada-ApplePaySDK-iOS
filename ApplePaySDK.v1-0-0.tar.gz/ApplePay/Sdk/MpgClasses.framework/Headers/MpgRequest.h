//
//  MpgRequest.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"
#define MPG_PROC_COUNTRY_CANADA = @"CA"
#define MPG_PROC_COUNTRY_US = @"US"

@interface MpgRequest : MpgTransaction
{
    @private
    MpgTransaction *trxn;
    
    @package
    NSString *host;
    NSString *storeId;
    NSString *apiToken;
    
    BOOL sendToTestEnv;
}

+(id)mpgRequestWithStoreId:(NSString *)storeId ApiToken:(NSString *)apiToken Transaction:(MpgTransaction *)trxn;
-(void)setProcCountry:(NSString *)procCountry;
-(void)setTestMode:(bool)testMode;

@end
