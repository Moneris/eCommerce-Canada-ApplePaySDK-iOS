//
//  Recur.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"

@interface Recur : MpgTransaction
+(id) recurWithUnit:(NSString *)recurUnit StartNow:(NSString *)startNow StartDate:(NSString *) startDate NumberOfRecurs:(NSString *)numRecurs Period:(NSString *)period RecurAmount:(NSString *)recurAmount;

@end
