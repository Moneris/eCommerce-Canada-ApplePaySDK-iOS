//
//  MpgClasses.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MpgClasses.
FOUNDATION_EXPORT double MpgClassesVersionNumber;

//! Project version string for MpgClasses.
FOUNDATION_EXPORT const unsigned char MpgClassesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MpgClasses/PublicHeader.h>
#include <MpgClasses/MpgTransaction.h>
#include <MpgClasses/MpgRequest.h>
#include <MpgClasses/MpgResponse.h>
#include <MpgClasses/HttpsPostRequest.h>
// Transaction list
#include <MpgClasses/Purchase.h>
#include <MpgClasses/Recur.h>
#include <MpgClasses/CvdInfo.h>
#include <MpgClasses/AvsInfo.h>
#include <MpgClasses/CavvPurchase.h>
#include <MpgClasses/CavvPreauth.h>
#include <MpgClasses/ApplePayTokenPurchase.h>
#include <MpgClasses/ApplePayTokenPreauth.h>
