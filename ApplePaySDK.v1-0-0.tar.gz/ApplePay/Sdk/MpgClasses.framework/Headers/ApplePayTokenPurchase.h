//
//  ApplePayTokenPurchase.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"
#import "Recur.h"
#import "CvdInfo.h"
#import "AvsInfo.h"
#import <PassKit/PKPayment.h>

@interface ApplePayTokenPurchase : MpgTransaction
+(id) applePayTokenPurchaseWithOrderId:(NSString *) orderId Payment:(PKPayment *)payment;
-(void)setRecur:(Recur *) recurInfo;
-(void)setCvdInfo:(CvdInfo *)cvdInfo;
-(void)setAvsInfo:(AvsInfo *)avsInfo;
-(void)setCustInfoWithPayment:(PKPayment *)payment Instructions:(NSString *)instructions ShippingCost:(NSString *)shippingCost Tax1:(NSString *)tax1 Tax2:(NSString *)tax2 Tax3:(NSString *)tax3;

@end
