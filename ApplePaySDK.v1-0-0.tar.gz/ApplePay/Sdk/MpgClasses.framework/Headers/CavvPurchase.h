//
//  CavvPurchase.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"
#import "Recur.h"
#import "CvdInfo.h"
#import "AvsInfo.h"


@interface CavvPurchase : MpgTransaction
+(id) cavvPurchaseWithOrderId:(NSString *)orderId Amount:(NSString *)amount Pan:(NSString *) pan ExpDate:(NSString *)expDate CryptType:(NSString *)cryptType Cavv:(NSString *) cavv;
-(void)setWalletIndicator:(NSString *)walletIndicator;
-(void)setCvdInfo:(CvdInfo *)cvdInfo;
-(void)setAvsInfo:(AvsInfo *)avsInfo;
-(void)setRecur:(Recur *) recurInfo;

@end
