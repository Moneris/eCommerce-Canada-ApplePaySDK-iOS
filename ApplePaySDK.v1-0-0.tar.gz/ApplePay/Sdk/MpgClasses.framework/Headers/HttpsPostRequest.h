//
//  HttpsPostRequest.h
//  PaydPro
//
//  Created by Moneris Solutions on 12/05/15
//
//

#import <Foundation/Foundation.h>
#import "MpgTransaction.h"
#import "MpgRequest.h"
#import "MpgResponse.h"

@class HttpsPostRequest;

@interface HttpsPostRequest : NSObject

@property (strong, atomic) NSString *host;
@property (strong, atomic) MpgRequest *request;
@property (strong, atomic) MpgResponse *response;

-(id) initWithHost:(NSString *) requestHost Request:(MpgRequest *)req;


@end
