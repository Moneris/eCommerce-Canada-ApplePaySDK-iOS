//
//  MpgResponse.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-20.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MpgResponse : NSObject
{
    @private
    NSDictionary *responseMap;
}

-(NSString *)getRecurSuccess;
-(NSString *)getStatusCode;
-(NSString *)getStatusMessage;
-(NSString *)getAvsResultCode;
-(NSString *)getCvdResultCode;
-(NSString *)getCardType;
-(NSString *)getTransAmount;
-(NSString *)getTxnNumber;
-(NSString *)getReceiptId;
-(NSString *)getTransType;
-(NSString *)getReferenceNum;
-(NSString *)getResponseCode;
-(NSString *)getISO;
-(NSString *)getBankTotals;
-(NSString *)getMessage;
-(NSString *)getAuthCode;
-(NSString *)getComplete;
-(NSString *)getTransDate;
-(NSString *)getTransTime;
-(NSString *)getTicket;
-(NSString *)getTimedOut;
-(NSString *)getCorporateCard;
-(NSString *)getCavvResultCode;
-(NSString *)getCardLevelResult;
-(NSString *)getITDResponse;
-(NSString *)getIsVisaDebit;
-(NSString *)getMaskedPan;
-(NSString *)getCavv;
-(NSString *)getDeviceManufacturerIdentifier;
@end
