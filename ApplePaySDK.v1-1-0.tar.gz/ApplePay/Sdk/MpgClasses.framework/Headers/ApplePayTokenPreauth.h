//
//  ApplePayTokenPreauth.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-25.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"
#import "Recur.h"
#import "CvdInfo.h"
#import "AvsInfo.h"
#import <PassKit/PKPayment.h>

@interface ApplePayTokenPreauth : MpgTransaction

+(id)applePayTokenPreauthWithOrderId:(NSString *) orderId Payment:(PKPayment *)payment;
-(void)setCustInfoWithPayment:(PKPayment *)payment Instructions:(NSString *)instructions ShippingCost:(NSString *)shippingCost Tax1:(NSString *)tax1 Tax2:(NSString *)tax2 Tax3:(NSString *)tax3;
-(void)setRecur:(Recur *) recurInfo;
-(void)setCvdInfo:(CvdInfo *)cvdInfo;
-(void)setAvsInfo:(AvsInfo *)avsInfo;

@end
