//
//  CvdInfo.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "MpgTransaction.h"

@interface CvdInfo : MpgTransaction
+(id) cvdInfoWithIndicator:(NSString *)cvdIndicator Value:(NSString *)cvdValue;

@end
