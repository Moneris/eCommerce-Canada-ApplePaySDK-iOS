//
//  MpgTransaction.h
//  MpgClasses
//
//  Created by Moneris Solutions on 2015-05-12.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MpgTransaction : NSObject
{
    @package
    NSMutableDictionary *params;
    NSString *transactionType;
}

-(id)initWithParams: (NSDictionary *) params;
-(NSString *)toXML;

@end
