//
//  ViewController.h
//  projnorth
//
//  Created by Moneris Solutions on 2015-04-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIRecurViewController.h"
@import PassKit;

@interface ViewController : UIViewController <PKPaymentAuthorizationViewControllerDelegate, UIActionSheetDelegate>

@property (nonatomic, strong) IBOutlet PKPaymentButton *btnPay;
@property (nonatomic, strong) IBOutlet UIButton *btnRecur;
@property (nonatomic, strong) IBOutlet UIButton *btnTransType;

@property (nonatomic, strong) IBOutlet UITextField *txtAmount;
@property (nonatomic, strong) IBOutlet UITextView *txtReceipt;

-(IBAction)pommeButtonDidPress:(id)sender;
-(IBAction)recurButtonDidPress:(id)sender;
-(IBAction)transTypeButtonDidPress:(id)sender;

#pragma mark PasskitPayment
@property (nonatomic, strong) NSArray *paymentNetworks;
@property (nonatomic, strong) PKPaymentRequest *request;
@property (nonatomic, strong) PKPaymentSummaryItem *subtotal;

@property (nonatomic, unsafe_unretained)NSInteger selectedIdx;
@property (nonatomic, strong) id recurInfoView;
-(void)recurEnabled:(BOOL)enabled startNow:(BOOL)startNow numRecur:(NSInteger)numRecur amount:(NSString *)amount startDate:(NSString *)date unit:(NSString *)unit interval:(NSInteger) interval;

@property (unsafe_unretained, nonatomic) BOOL hasRecur;

@property (nonatomic, strong) NSString *transAmount;

@property (nonatomic, strong) NSString *recurStartNow;
@property (nonatomic, strong) NSString *recurAmount;

@property (nonatomic, strong) NSString *recurStartDate;
@property (nonatomic, strong) NSString *recurUnit;
@property (nonatomic, unsafe_unretained) NSInteger recurInterval;
@property (nonatomic, unsafe_unretained) NSInteger numOfRecurs;
@property (nonatomic, unsafe_unretained) BOOL configured;

@end

