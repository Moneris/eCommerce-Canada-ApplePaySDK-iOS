//
//  UIRecurViewController.h
//  projnorth
//
//  Created by Moneris Solutions on 2015-06-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface UIRecurViewController : UIViewController <UIActionSheetDelegate, UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UISwitch *swtRecurEnabled;
@property (nonatomic, strong) IBOutlet UISwitch *swtStartNow;
@property (nonatomic, strong) IBOutlet UISlider *sldNumRecur;
@property (nonatomic, strong) IBOutlet UISlider *sldInterval;
@property (nonatomic, strong) IBOutlet UILabel *lblInterval;

@property (nonatomic, strong) IBOutlet UITextField *txtRecurAmount;
@property (nonatomic, strong) IBOutlet UIButton *btnRecurPeriod;
@property (nonatomic, strong) IBOutlet UIButton *btnRecurDate;
@property (nonatomic, strong) IBOutlet UIButton *btnRecurViewClose;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UILabel *lblNumRecur;

-(IBAction)recurPeriodButtonDidPress:(id)sender;
-(IBAction)recurDateButtonDidPress:(id)sender;
-(IBAction)recurViewCloseButtonDidPress:(id)sender;

@property (nonatomic, unsafe_unretained) BOOL configured;
@property (nonatomic, unsafe_unretained) BOOL recurEnabled;
@property (nonatomic, unsafe_unretained) NSInteger recurPeriodIdx;
@property (nonatomic, strong, getter=getRecurPeriodOptions) NSArray *recurPeriodOptions;
@property (nonatomic, strong) NSString *recurAmount;
@property (nonatomic, unsafe_unretained) NSInteger numRecur;
@property (nonatomic, unsafe_unretained) BOOL startNow;
@property (nonatomic, strong) NSDate *startDate;
@property (nonatomic, unsafe_unretained)NSInteger recurInterval;
@property (nonatomic, strong) NSString *transAmount;

-(void)setRecurEnabled:(BOOL)enabled startNow:(BOOL)startNow transAmount:(NSString *)transAmount recurAmount:(NSString *)amount startDate:(NSString *)date numOfRecur:(NSInteger)numRecur unit:(NSString *)unit interval:(NSInteger)interval;

@end
