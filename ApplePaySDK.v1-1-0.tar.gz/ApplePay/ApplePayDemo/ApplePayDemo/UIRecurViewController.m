//
//  UIRecurViewController.m
//  projnorth
//
//  Created by Moneris Solutions on 2015-06-22.
//  Copyright (c) 2015 Moneris Solutions. All rights reserved.
//

#import "UIRecurViewController.h"

@interface UIRecurViewController ()

@end

@implementation UIRecurViewController
- (id)init
{
    if (self == [super init])
    {
        self.numRecur = 0;
        self.configured = YES;
        self.recurPeriodIdx = -1;
        self.startDate = [[NSDate date] dateByAddingTimeInterval:60*60*24];
        self.recurInterval = 0;
        
        self.sldNumRecur.continuous = NO;
        self.sldNumRecur.value = 0;
        self.sldInterval.continuous = NO;
        self.sldInterval.value = 0;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    


    
    [self.swtRecurEnabled setOn:self.recurEnabled];
    [self.swtStartNow setOn:self.startNow];
    [self.txtRecurAmount setText:self.recurAmount];
    [self.lblNumRecur setText:[NSString stringWithFormat:@"%ld", self.numRecur]];
    [self.sldNumRecur setValue:(float)self.numRecur];
    [self.lblInterval setText:[NSString stringWithFormat:@"Every %ld", self.recurInterval]];
    [self.sldInterval setValue:(float)self.recurInterval];
    
    if (self.recurPeriodIdx < [self.recurPeriodOptions count])
    {
        [self.btnRecurPeriod setTitle:[self.recurPeriodOptions objectAtIndex:self.recurPeriodIdx] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnRecurPeriod setTitle:@"Select Recur Period" forState:UIControlStateNormal];
    }
    
    [self updateDateButton];
    self.txtRecurAmount.delegate = self;
    [self.txtRecurAmount addTarget:self action:@selector(dismissRecurAmountKeyboard:) forControlEvents:UIControlEventEditingDidEndOnExit];
    [self.sldNumRecur addTarget:self action:@selector(numRecurSliderDidChange:) forControlEvents:UIControlEventValueChanged];
    [self.sldInterval addTarget:self action:@selector(intervalSliderDidChange:) forControlEvents:UIControlEventValueChanged];
    
    [self.sldNumRecur addTarget:self action:@selector(dismissRecurAmountKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    [self.swtRecurEnabled addTarget:self action:@selector(dismissRecurAmountKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    [self.swtStartNow addTarget:self action:@selector(dismissRecurAmountKeyboard:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.swtRecurEnabled setOn:self.recurEnabled];

}
-(NSArray *)getRecurPeriodOptions
{
    if (_recurPeriodOptions == nil)
    {
            _recurPeriodOptions = [[NSArray alloc] initWithObjects:@"day", @"week", @"month", nil];
    }
    return _recurPeriodOptions;
}
-(void) updateDateButton
{
    if (self.startDate == nil)
    {
        self.startDate = [[NSDate date] dateByAddingTimeInterval:60*60*24];
    }
        
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd"];
    [self.btnRecurDate setTitle:[dateFormatter stringFromDate:self.startDate] forState:UIControlStateNormal];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.btnRecurViewClose.frame = CGRectMake(self.btnRecurViewClose.frame.origin.x, self.btnRecurViewClose.frame.origin.y - 215, self.btnRecurViewClose.frame.size.width, self.btnRecurViewClose.frame.size.height);
    [self.view setNeedsDisplay];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    self.btnRecurViewClose.frame = CGRectMake(self.btnRecurViewClose.frame.origin.x, self.btnRecurViewClose.frame.origin.y + 215, self.btnRecurViewClose.frame.size.width, self.btnRecurViewClose.frame.size.height);
    [self.view setNeedsDisplay];
}

- (void)dismissRecurAmountKeyboard:(id)sender
{
    
    [self.txtRecurAmount resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)numRecurSliderDidChange:(id)sender
{
    [self.lblNumRecur setText:[NSString stringWithFormat:@"%d", (int)[self.sldNumRecur value]]];
    self.numRecur = (int)[self.sldNumRecur value];
}

-(void)intervalSliderDidChange:(id)sender
{
    [self.lblInterval setText:[NSString stringWithFormat:@"Every %d", (int)[self.sldInterval value]]];
    self.recurInterval = (int)[self.sldInterval value];
}

-(void)recurPeriodButtonDidPress:(id)sender
{
    [self dismissRecurAmountKeyboard:sender];
    UIActionSheet *recurPeriodSheet = [[UIActionSheet alloc] initWithTitle:@"Select Recur Period" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"day", @"week", @"month", nil];
    [recurPeriodSheet showInView:self.view];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    self.recurPeriodIdx = buttonIndex;
    if (buttonIndex < [self.recurPeriodOptions count])
    {
        [self.btnRecurPeriod setTitle:[self.recurPeriodOptions objectAtIndex:buttonIndex] forState:UIControlStateNormal];
    }
}
-(void)recurDateButtonDidPress:(id)sender
{
    [self dismissRecurAmountKeyboard:sender];
    
    UIAlertController *datePickAlert = [UIAlertController alertControllerWithTitle:@"Start Date" message:@"Select Start Date (Must be tomorrow or later)" preferredStyle:UIAlertControllerStyleActionSheet];
    
    self.datePicker =[[UIDatePicker alloc]init];
    self.datePicker.datePickerMode=UIDatePickerModeDate;
    self.datePicker.hidden=NO;
    self.datePicker.date=self.startDate;
    [self.datePicker addTarget:self action:@selector(recurDateHasChanged:) forControlEvents:UIControlEventValueChanged];
    
    [datePickAlert.view addSubview:self.datePicker];

    
    UIButton *datePickOk = [[UIButton alloc] initWithFrame:CGRectMake(0,0,100,30)];
    
    [datePickOk setTitle:@"OK" forState:UIControlStateNormal];
    [datePickOk setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [datePickOk addTarget:self action:@selector(recurDateUpdated:) forControlEvents:UIControlEventTouchUpInside];
    [datePickAlert.view addSubview:datePickOk];

    [self.datePicker setTranslatesAutoresizingMaskIntoConstraints:NO];
    [datePickOk setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    NSDictionary *labelViewDictionary = [NSDictionary dictionaryWithObjectsAndKeys:self.datePicker, @"datePicker", datePickOk, @"datePickOk", nil];
    
    NSArray* hDatePickConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[datePicker]-|" options:0 metrics:nil views:labelViewDictionary];
    [datePickAlert.view addConstraints:hDatePickConstraints];
    NSArray* hOkConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[datePickOk]-|" options:0 metrics:nil views:labelViewDictionary];
    [datePickAlert.view addConstraints:hOkConstraints];
    NSArray* vConstraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-50-[datePicker]-[datePickOk]-15-|" options:0 metrics:nil views:labelViewDictionary];
    [datePickAlert.view addConstraints:vConstraints];
    
    [self presentViewController:datePickAlert animated:YES completion:nil];
}

-(void)setRecurEnabled:(BOOL)enabled startNow:(BOOL)startNow transAmount:(NSString *)transAmount recurAmount:(NSString *)amount startDate:(NSString *)recurStartDate numOfRecur:(NSInteger)numRecur unit:(NSString *)unit interval:(NSInteger)interval
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd"];
    
    self.configured = YES;
    self.transAmount = transAmount;
    self.recurEnabled = enabled;
    self.startNow = startNow;
    self.recurAmount = amount;
    self.startDate = [dateFormatter dateFromString:recurStartDate];
    self.numRecur = numRecur;
    self.recurInterval = interval;
    
    self.recurPeriodIdx = [self.recurPeriodOptions indexOfObject:unit];
    if (unit != nil)
    {
        [self.btnRecurPeriod setTitle:unit forState:UIControlStateNormal];
    }
    
}
-(void)recurDateHasChanged:(id)sender
{
    if ([self.datePicker.date compare:[[NSDate date] dateByAddingTimeInterval:60*60*24]] == NSOrderedAscending)
    {
        [self.datePicker setDate:[[NSDate date] dateByAddingTimeInterval:60*60*24]];
    }
    
}

-(void)recurDateUpdated:(id)sender
{
    self.startDate = [self.datePicker date];
    [self dismissViewControllerAnimated:NO completion:nil];
    [self updateDateButton];
}

-(void)recurViewCloseButtonDidPress:(id)sender
{
    [self performSegueWithIdentifier:@"recurSave" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"recurSave"])
    {
        ViewController * parentView = (ViewController *)[segue destinationViewController];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyy/MM/dd"];
        [parentView recurEnabled:self.swtRecurEnabled.isOn startNow:self.swtStartNow.isOn numRecur:self.numRecur amount:self.txtRecurAmount.text startDate:[dateFormatter stringFromDate:[self.datePicker date]] unit:self.btnRecurPeriod.titleLabel.text interval:(int)[self.sldInterval value]];
        [parentView setTransAmount:self.transAmount];
    }
}

@end
